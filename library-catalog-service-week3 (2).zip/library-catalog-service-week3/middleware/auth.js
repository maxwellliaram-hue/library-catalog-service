const jwt = require("jsonwebtoken");
const User = require("../models/User");

function getToken(req) {
  if (req.cookies && req.cookies.token) return req.cookies.token;
  const header = req.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7) : null;
}

async function requireAuth(req, res, next) {
  const token = getToken(req);
  if (!token) return res.status(401).json({ message: "Authentication required" });
  if (!process.env.JWT_SECRET) return res.status(500).json({ message: "Authentication is not configured" });

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.sub).select("_id username email role");
    if (!user) return res.status(401).json({ message: "Invalid or expired session" });
    req.user = user;
    return next();
  } catch (_error) {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: "Authentication required" });
    if (req.user.role !== role) return res.status(403).json({ message: "Forbidden: insufficient role" });
    return next();
  };
}

module.exports = { requireAuth, requireRole };
